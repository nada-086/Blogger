from flask_sqlalchemy import SQLAlchemy
from app import db

class Order(db.Model):
    __tablename__ = 'order'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(20), nullable=False, unique=True)
    price = db.Column(db.Integer, nullable=False)
    # product_id = db.mapped_column(db.ForeignKey("product.id"))
    # product = db.relationship("Product", back_populates="order", single_parent=True)
