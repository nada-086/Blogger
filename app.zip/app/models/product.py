from flask_sqlalchemy import SQLAlchemy
from app import db

class Product(db.Model):
    __tablename__ = 'product'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(20), nullable=False, unique=True)
    last_name = db.Column(db.String(20), nullable=False, unique=True)
    llast_name = db.Column(db.String(20), nullable=False, unique=True)
    price = db.Column(db.Integer, nullable=False)
    # order = db.relationship("Order", back_populates="product")