from flask import Blueprint, request, jsonify, render_template, redirect
from flask_injector import inject
from app.models.user import User
from app.services.user import UserService

auth = Blueprint("auth", __name__)

@auth.route('/')
def profile():
    return render_template('/auth/profile.html')

@auth.route('/login')
def login_form():
    return render_template("/auth/login.html")

@auth.route('/login', methods=['POST'])
@inject
def login(user_service: UserService):
    name = request.form.get('name')
    password = request.form.get('password')

    if not name and not password:
        return jsonify({
        "msg": "please enter name and password"
    }), 400

    status = user_service.login(name=name, price=password)

    if not status:
        return jsonify({
            "msg": "Incorrect user or password"
        }), 400
    else:
        return redirect('/auth/')

@auth.route('/signup')
def signup_form():
    return render_template("/auth/signup.html")