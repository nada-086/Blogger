from flask import Blueprint, request, jsonify, render_template, redirect
from flask_injector import inject
from app.models.product import Product
from app.services.products import ProductService

products = Blueprint("products", __name__)

@products.route('/')
@inject
def list_products(product_service: ProductService):
    return render_template('products/list.html', products=product_service.get_all())

@products.route('/create')
def create_product():
    return render_template("/products/create.html")

@products.route('/', methods=['POST'])
@inject
def store_product(product_service: ProductService):
    product_name = request.form.get('name')
    product_price = request.form.get('price')

    if not product_name and not product_price:
        return jsonify({
        "msg": "please enter product's name and price"
    }), 400

    try:
        product_service.create(name=product_name, price=product_price)
    except:
        return jsonify({
            "msg": "please enter price greater than zero"
        }), 400

    return render_template('products/list.html', products=product_service.get_all(), msg="Added product successfully")

@products.route('/<id>')
@inject
def view_product(product_service: ProductService, id):
    product = product_service.get_by_id(id)

    if not product:
        return redirect('/products')

    return render_template('products/view.html', product=product)

@products.route('/<id>/edit')
@inject
def edit_product(product_service: ProductService, id):
    product = product_service.get_by_id(id)

    if not product:
        return redirect('/products')

    return render_template('products/edit.html', product=product)

@products.route('/<id>', methods=['POST'])
@inject
def update_product(product_service: ProductService, id):
    product = product_service.get_by_id(id)

    if not product:
        return jsonify({
            "msg": "there is no product with the entered id"
        }), 400

    product_name = request.form.get('name')
    product_price = request.form.get('price')

    if not product_name and not product_price:
        return jsonify({
        "msg": "please enter product's name and price"
    }), 400

    product_service.update(product, product_name, product_price)

    return render_template('products/view.html', product=product)

@products.route('/<id>', methods=['DELETE'])
@inject
def delete_product(product_service: ProductService, id):
    product = product_service.get_by_id(id)

    if not product:
        return redirect('/products')

    product_service.delete(product)

    return render_template('products/list.html', products=product_service.get_all())