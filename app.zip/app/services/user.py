from app.models.user import User
from flask_sqlalchemy import SQLAlchemy
from flask_injector import inject
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import login_user


class UserService:
    @inject
    def __init__(self, db: SQLAlchemy):
        self.db = db

    def login(self, name, password):
        user = db.session.query(User).find_by(name=name).first()

        if not user or not check_password_hash(password, user.password):
            return False

        login_user(user)

        return True
