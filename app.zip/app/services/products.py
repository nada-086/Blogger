from app.models.product import Product
from app.models.order import Order
from flask_sqlalchemy import SQLAlchemy
from flask_injector import inject

class ProductService:
    @inject
    def __init__(self, db: SQLAlchemy):
        self.db = db

    def get_all(self):
        orders = self.db.session.query(Order).all()
        return self.db.session.query(Product).all()

    def create(self, name, price):
        product = Product(name=name, price=price)
        self.db.session.add(product)
        self.db.session.commit()

    def get_by_id(self, id):
        return self.db.session.query(Product).get(id)

    def update(self, product, name, price):
        product.name = product_name
        product.price = product_price
        self.db.session.commit()

    def delete(self, product):
        self.db.session.delete(product)
        self.db.session.commit()

